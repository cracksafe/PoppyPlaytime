# Natsurainko.FluentLauncher

<!-- PROJECT SHIELDS -->

[![Contributors][contributors-shield]][contributors-url]
[![Forks][forks-shield]][forks-url]
[![Stargazers][stars-shield]][stars-url]
[![Issues][issues-shield]][issues-url]
[![MIT License][license-shield]][license-url]

<!-- PROJECT LOGO -->
<br />

<p align="center">
  <a href="https://github.com/Xcube-Studio/Natsurainko.FluentLauncher/">
    <img src="docs/images/AppIcon.png" alt="Logo" width="80" height="80">
  </a>

  <h3 align="center">Natsurainko.FluentLauncher</h3>
  <p align="center">
    A launcher for Minecraft: Java Edition designed with WinUI 3
    <br />
    <p align="center">
      <a href="https://github.com/Xcube-Studio/Natsurainko.FluentLauncher">简体中文</a> |
      English
    </p>
    <p align="center">
      <a href="https://github.com/Xcube-Studio/Natsurainko.FluentLauncher">Documentation</a>
      ·
      <a href="https://github.com/Xcube-Studio/Natsurainko.FluentLauncher/releases">Releases</a>
      ·
      <a href="https://github.com/Xcube-Studio/Natsurainko.FluentLauncher/issues">Report Bug</a>
      ·
      <a href="https://github.com/Xcube-Studio/Natsurainko.FluentLauncher/issues">Feature Request</a>
    </p>
  </p>
</p>

# TODO: Translation