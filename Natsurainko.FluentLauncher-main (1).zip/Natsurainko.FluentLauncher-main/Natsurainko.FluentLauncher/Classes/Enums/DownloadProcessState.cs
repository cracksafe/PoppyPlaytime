﻿namespace Natsurainko.FluentLauncher.Classes.Enums;

public enum ResourceDownloadProcessState
{
    Created = 0,
    Downloading = 1,
    Finished = 2,
    Faulted = 3,
}
