﻿namespace Natsurainko.FluentLauncher.Classes.Data.UI;

internal enum MicrosoftAuthMethod
{
    BuiltInBrowser,
    DeviceFlowCode,
}
