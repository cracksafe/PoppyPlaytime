using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.CoreInstallWizard;

public sealed partial class AdditionalOptionsPage : Page
{
    public AdditionalOptionsPage()
    {
        this.InitializeComponent();
    }
}
