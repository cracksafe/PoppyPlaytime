using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Downloads;

public sealed partial class ResourcesSearchPage : Page
{
    public ResourcesSearchPage()
    {
        this.InitializeComponent();
    }
}
