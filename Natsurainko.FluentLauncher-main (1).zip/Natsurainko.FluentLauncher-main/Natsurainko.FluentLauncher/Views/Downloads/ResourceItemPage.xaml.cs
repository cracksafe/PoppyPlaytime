using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Downloads;

public sealed partial class ResourceItemPage : Page
{
    public ResourceItemPage()
    {
        this.InitializeComponent();
    }
}
