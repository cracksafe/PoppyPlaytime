using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Downloads;

public sealed partial class DownloadsPage : Page
{
    public DownloadsPage()
    {
        InitializeComponent();
    }
}
