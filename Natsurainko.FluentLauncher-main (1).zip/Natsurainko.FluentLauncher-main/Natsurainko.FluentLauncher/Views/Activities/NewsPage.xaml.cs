using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Activities;

public sealed partial class NewsPage : Page
{
    public NewsPage()
    {
        InitializeComponent();
    }
}
