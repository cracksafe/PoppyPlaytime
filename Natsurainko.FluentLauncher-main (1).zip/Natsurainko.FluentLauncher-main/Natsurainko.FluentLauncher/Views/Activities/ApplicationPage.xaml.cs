using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Activities;

public sealed partial class ApplicationPage : Page
{
    public ApplicationPage()
    {
        InitializeComponent();
    }
}
