using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Activities;

public sealed partial class LaunchPage : Page
{
    public LaunchPage()
    {
        InitializeComponent();
    }
}
