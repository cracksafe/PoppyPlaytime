using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Activities;

public sealed partial class DownloadPage : Page
{
    public DownloadPage()
    {
        InitializeComponent();
    }
}
