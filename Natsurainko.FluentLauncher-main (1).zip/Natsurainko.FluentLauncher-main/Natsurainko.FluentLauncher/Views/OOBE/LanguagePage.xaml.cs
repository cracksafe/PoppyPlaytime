using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.OOBE;

public sealed partial class LanguagePage : Page
{
    public LanguagePage()
    {
        InitializeComponent();
    }
}
