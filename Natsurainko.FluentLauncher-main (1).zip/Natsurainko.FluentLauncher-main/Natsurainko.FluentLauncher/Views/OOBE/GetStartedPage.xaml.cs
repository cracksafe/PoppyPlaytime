using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.OOBE;

public sealed partial class GetStartedPage : Page
{
    public GetStartedPage()
    {
        InitializeComponent();
    }
}
