using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.AuthenticationWizard;

public sealed partial class ChooseMicrosoftAuthMethodPage : Page
{
    public ChooseMicrosoftAuthMethodPage()
    {
        this.InitializeComponent();
    }
}
