using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.AuthenticationWizard;

public sealed partial class ConfirmProfilePage : Page
{
    public ConfirmProfilePage()
    {
        this.InitializeComponent();
    }
}
