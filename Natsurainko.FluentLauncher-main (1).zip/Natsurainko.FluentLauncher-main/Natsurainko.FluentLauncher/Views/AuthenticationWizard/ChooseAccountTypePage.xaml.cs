using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.AuthenticationWizard;

public sealed partial class ChooseAccountTypePage : Page
{
    public ChooseAccountTypePage()
    {
        this.InitializeComponent();
    }
}
