using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.AuthenticationWizard;

public sealed partial class BrowserMicrosoftAuthPage : Page
{
    public BrowserMicrosoftAuthPage()
    {
        this.InitializeComponent();
    }
}
