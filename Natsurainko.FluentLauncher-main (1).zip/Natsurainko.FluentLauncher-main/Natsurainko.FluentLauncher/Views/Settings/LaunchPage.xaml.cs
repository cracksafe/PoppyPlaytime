using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Settings;

public sealed partial class LaunchPage : Page
{
    public LaunchPage()
    {
        InitializeComponent();
    }
}
