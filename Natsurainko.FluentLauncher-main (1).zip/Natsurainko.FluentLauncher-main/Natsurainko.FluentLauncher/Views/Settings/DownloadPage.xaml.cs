using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Settings;

public sealed partial class DownloadPage : Page
{
    public DownloadPage()
    {
        InitializeComponent();
    }
}
