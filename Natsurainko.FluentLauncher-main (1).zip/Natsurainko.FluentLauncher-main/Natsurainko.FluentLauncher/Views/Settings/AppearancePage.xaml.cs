using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Settings;

public sealed partial class AppearancePage : Page
{
    public AppearancePage()
    {
        InitializeComponent();
    }
}
