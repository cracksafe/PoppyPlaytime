using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Settings;

public sealed partial class AccountPage : Page
{
    public AccountPage()
    {
        InitializeComponent();
    }
}
