using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Cores.Manage;

public sealed partial class CoreStatisticPage : Page
{
    public CoreStatisticPage()
    {
        this.InitializeComponent();
    }
}
