using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Common;

public sealed partial class CopyrightLicenseDialog : ContentDialog
{
    public CopyrightLicenseDialog()
    {
        this.InitializeComponent();
    }
}
