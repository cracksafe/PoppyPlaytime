using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Common;

public sealed partial class DeleteGameDialog : ContentDialog
{
    public DeleteGameDialog()
    {
        this.InitializeComponent();
    }
}
