using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Common;

public sealed partial class AuthenticationWizardDialog : ContentDialog
{
    public AuthenticationWizardDialog()
    {
        this.InitializeComponent();
    }
}
