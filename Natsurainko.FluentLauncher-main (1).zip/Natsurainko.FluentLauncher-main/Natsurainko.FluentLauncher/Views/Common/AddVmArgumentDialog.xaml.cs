using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Common;

public sealed partial class AddVmArgumentDialog : ContentDialog
{
    public AddVmArgumentDialog()
    {
        this.InitializeComponent();
    }
}
