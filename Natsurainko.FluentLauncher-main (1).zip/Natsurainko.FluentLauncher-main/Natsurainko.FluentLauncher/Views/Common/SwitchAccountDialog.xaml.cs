using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views.Common
{
    public sealed partial class SwitchAccountDialog : ContentDialog
    {
        public SwitchAccountDialog()
        {
            this.InitializeComponent();
        }
    }
}
