using Microsoft.UI.Xaml.Controls;

namespace Natsurainko.FluentLauncher.Views;

public sealed partial class LoggerPage : Page
{
    public LoggerPage()
    {
        this.InitializeComponent();
    }
}
